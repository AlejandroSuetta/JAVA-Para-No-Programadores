/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratorio_clae4;

import java.util.Scanner;

/**
 *
 * @author Suetta
 */
public class Laboratorio_clae4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        /* Ejersicio 1 */
        int [] n1 = new int [6];
            n1 [0] = 10;
            n1 [1] = 20;
            n1 [2] = 5;
            n1 [3] = 15;
            n1 [4] = 30;
            n1 [5] = 20;
            
        System.out.println("Ejersicio 1");
            
        for (int a = 0; a < n1.length; a++) /* Para informar todol los indices con sus valores */
        {
            System.out.println("Indice: " + a + " Valor: " + n1[a]);
        }
        
        int suma= 0;
        
        for (int a1 = 0; a1 < n1.length; a1++) /* Para sumar todos los valores */
        {
            suma = suma + n1[a1];
        }
        
        System.out.println(suma);
        
        for (int a2 = 0; a2 < n1.length; ++a2) /* Para informar solo los de indice impar */
        {
           int resto = a2 % 2;
            
            if (resto != 0)
            {
                System.out.println(n1[a2]);
            }       
        }
        
        int mayor = 0;
        
        for (int a3 = 0; a3 < n1.length; a3++) /* Para infrmar el indice con mayor valor */
        {
            if (n1[a3] > mayor)
            {
                mayor = n1[a3];
            }
        }
        
        System.out.println(mayor);
        
        int veces = 0;
        
        for (int a4 = 0; a4 < n1.length; a4++) /* Para podes calcular cuantas veces aparece el 20 como valor del vector */
        {
            if (n1[a4] == 20)
            {
                ++veces;
            }  
        }
        
        System.out.println(veces);
        
        /* Ejersicio 2 */
        double [] n2 = {0.8, 0.1, 0.3, 0.4, 0.3, 0.6, 0.5, 0.3, 0.7, 0.3, 0.2, 0.9};
        
        System.out.println("Ejersicio 2");
        
        System.out.println("La inflación aunal es de " + ((n2[11] - n2[0])/n2[0])*100); /* Calculo de la inflación anual */
        
        double minimo = 1;
        
        int mes = 0;
        
        for (int b = 0; b < n2.length; b++) /* Para calcular el mes de la inflación minima */
        {
            if (n2[b] < minimo)
            {
                minimo = n2[b];
                
                mes = b + 1;
            }
        }
        
        System.out.println("La inflación minima fue en el mes " + mes + " con un valor de " + minimo);
        
        double maximo = 0;
        
        int mes2 = 0;
        
        for (int b2 = 0; b2 < n2.length; b2++) /* Para calcular el mes de la inflacióm maxima */
        {
            if (n2[b2] > maximo)
            {
                maximo = n2[b2];
                
                mes2 = b2 + 1;
            }
        }
        
        System.out.println("La inflación maxima fue en el mes " + mes2 + " con un valor de " + maximo);
        
        double total = 0;
        
        for (int b3 = 0; b3 < n2.length; b3++) /* Para calcular el promedio de la inflación */
        {
            total = total + n2[b3];
        }
        
        System.out.println(total/12);
        
        /* Ejersicio 3 */
        double[] n3 = {0.8, 0.1, 0.3, 0.4, 0.3, 0.6, 0.5, 0.3, 0.7, 0.3, 0.2, 0.9};
        String[] month = {"enero","febrero","marzo","abri","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"};
        /* Uso un vector String para cambiar las variables mes3 y mes 4 por el valor del vector String apropiado */
        
        System.out.println("Ejersicio 3");
        
        String mes3 = "";
        minimo = 1;
        
        for (int c = 0; c < n3.length; c++)
        {
            if (n3[c] < minimo)
            {
                minimo = n3[c];
                
                mes3 = month[c];
            }
        }
        
        System.out.println("El valor minimo de inflación fue en " + mes3 + " y fue de " + minimo);
        
        String mes4 = "";
        maximo = 0;
        
        for (int c1 = 0; c1 < n3.length; c1++)
        {
            if (n3[c1] > maximo)
            {
                maximo = n3[c1];
                
                mes4 = month[c1];
            }
        }
        
        System.out.println("El mes con mayor inflación fue en " + mes4 + " y fue de " + maximo);
        
        /* Ejersicio 4 */
        double[] n4 = new double [6];
        
        System.out.println("Ejersicio 4");
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("A continuación ingrese la facturación de los últimos 6 mese. Solo puede ingresar números");
        
         n4[0] = Double.parseDouble(teclado.next());
         n4[1] = Double.parseDouble(teclado.next());
         n4[2] = Double.parseDouble(teclado.next());
         n4[3] = Double.parseDouble(teclado.next());
         n4[4] = Double.parseDouble(teclado.next());
         n4[5] = Double.parseDouble(teclado.next());
         
         double total2 = 0;
         
         for (int d = 0; d < n4.length; d++)
         {
             total2 = total2 + n4[d];
         }
         
         System.out.println("Facturación total = " + total2);
         
         System.out.println("Promedio de la Facturación = " + total2/6);
         
         double maximo4 = 0;
         
         for (int d1 = 0; d1 < n4.length; d1++)
         {
             if (n4[d1] > maximo)
             {
                 maximo = n4[d1];
             }
         }
         
         System.out.println("Facturacióm maxima = " + maximo);
         
         double minimo4 = n4[0];
         
         for (int d2 = 0; d2 < n4.length; d2++)
         {
             if (n4[d2] < minimo4)
             {
                 minimo4 = n4[d2];
             }
         }
         
         System.out.println("Facturación minima = " + minimo4);
         
         /* Ejersicio 5 */
         int[] origen = {5, 20, 3, 8, 12};
         int[] destino = new int [origen.length];
         
         System.out.println("Ejersicio 5");
         
         for (int e = 0; e < origen.length; e++)
         {
             System.arraycopy (origen, e, destino, e, 1);
         }
         
         for (int e1 = 0; e1 < destino.length; e1++)
         {
             System.out.println(destino[e1]);
         }
         
         /* Ejersicio 6 */
         int[] origen2 = {1002, 104, 309, 500};
         int[] destino2 = new int [origen2.length];
         
         System.out.println("Ejersicio 6");
         
         int m = 3;
         
         for (int f = 0; f < origen2.length; f++)
         {
             System.arraycopy (origen2, m, destino2, f, 1);
             
             m--;
         }
         
         for (int f1 = 0; f1 < destino2.length; f1++)
         {
             System.out.println(destino2[f1]);
         }
         
         /* Ejersicio 7*/
         double[] n7 = {253.23, 621.32, 223.14, 568.21, 102.98, 556.12, 421.56, 426.14, 125.23, 235.21, 356.21, 498.99};
         double[] trimestre = new double [4];
         
         System.out.println("Ejersicio 7");
         
         double sumat1 = 0;
         double sumat2 = 0;
         double sumat3 = 0;
         double sumat4 = 0;
         
         for (int g = 0; g < n7.length; g++)
         {
             if (g < 3)
             {
                 sumat1 = sumat1 + n7[g];
                 
                 trimestre[0] = sumat1;
             }
             
             else if ((g < 6) & (g >= 3))
             {
                 sumat2 = sumat2 + n7[g];
                 
                 trimestre[1] = sumat2;
             }
             
             else if ((g < 9) & (g >= 6))
             {
                 sumat3 = sumat3 + n7[g];
                 
                 trimestre[2] = sumat3;
             }
             
             else
             {
                 sumat4 = sumat4 + n7[g];
                 
                 trimestre[3] = sumat4;
             }
         }
         
         for (int g1 = 0; g1 < trimestre.length; g1++)
         {
             System.out.println(trimestre[g1]);
         }
         
         /* Ejersicio de la clase */
         double [] facturacion = new double [12];
        
         System.out.println("Ejercio de la clase");
         
         System.out.println("A continuación, ingrese la facturación para cada mes (de enero a diciembre. Solo se aceptan números");
         facturacion[0] = Double.parseDouble(teclado.next());
         facturacion[1] = Double.parseDouble(teclado.next());
         facturacion[2] = Double.parseDouble(teclado.next());
         facturacion[3] = Double.parseDouble(teclado.next());
         facturacion[4] = Double.parseDouble(teclado.next());
         facturacion[5] = Double.parseDouble(teclado.next());
         facturacion[6] = Double.parseDouble(teclado.next());
         facturacion[7] = Double.parseDouble(teclado.next());
         facturacion[8] = Double.parseDouble(teclado.next());
         facturacion[9] = Double.parseDouble(teclado.next());
         facturacion[10] = Double.parseDouble(teclado.next());
         facturacion[11] = Double.parseDouble(teclado.next());
         
         for (int h = 0; h < facturacion.length; h++)
         {
             System.out.println("La facturación para el mes " + (h + 1) + " fue de " + facturacion[h]);
         }
         
         double totalfac = 0;
         
         for (int g1 = 0; g1 < facturacion.length; g1++)
         {
            totalfac = totalfac + facturacion[g1];
         }
         
         System.out.println("La facturación total es de " + totalfac);
         
         System.out.println("El promedio de la facturación es de " + (totalfac/12));
         
         double subt1 = 0;
         double subt2 = 0;
         double subt3 = 0;
         double subt4 = 0;
         
         for (int g2 = 0; g2 < facturacion.length; g2++)
         {
             if (g2 < 3)
             {
                 subt1 = subt1 + facturacion[g2];
             }
             
             else if ((g2 < 6) & (g2 >= 3))
             {
                 subt2 = subt2 + facturacion[g2];
             }
             
             else if ((g2 < 9) & (g2 >= 6))
             {
                 subt3 = subt3 + facturacion[g2];
             }
             
             else
             {
                 subt4 = subt4 + facturacion[g2];
             }
         }
         
        System.out.println("El subtotal para le primer trimestre es de " + subt1);
        System.out.println("El subtotal para le segundo trimestre es de " + subt2);
        System.out.println("El subtotal para le tercer trimestre es de " + subt3);
        System.out.println("El subtotal para le cuarto trimestre es de " + subt4);
    } 
}
