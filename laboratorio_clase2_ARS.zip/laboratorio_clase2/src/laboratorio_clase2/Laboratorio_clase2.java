/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratorio_clase2;

import java.util.Scanner;

/**
 *
 * @author Suetta
 */
public class Laboratorio_clase2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {/* Ejercisio 1 */
        int n1 = 100;
        int n2 = 500;
        int n3 = 250;
        
            if ((n1 > n2) & (n1 > n3)) /*Comparo n1 contra n2 y n3 para ver si es mas grande que los dos*/
            {
                System.out.println(n1 + " es el número más grande");
            }
            else if ((n2 > n1) & (n2 > n3)) /*En este y el siguiente se hace lo mismo que par el primero*/
            {
                System.out.println(n2 + " es el número más grande");
            }
            else if ((n3 > n1) & (n3 > n2))
            {
                System.out.println(n3 + " es el número más grande");
            }
        
     /* Ejercisio 2*/
        int a = 10, b = -2, c = 5;
        
            if (a > 0 & b > 0) /*Me fijo si son mayores a cero solo los que voy a intentar de multiplicar. Por est se pruban las tres opciones*/
            {
                System.out.println("El resultado de multiplicar 'a' y 'b' es " + (a * b));
            }
            else if (a > 0 & c > 0)
            {
                System.out.println("El resultado de multiplicar 'a' y 'c' es " + (a * c));
            }
            else if (b > 0 & c > 0)
            {
                System.out.println("El resultado de multiplicar 'b' y 'c' es " + (b * c));
            }
            
     /*Ejercisio 3*/
        String usuario = "Pepito", clave = "1234";
        
            if (usuario.equals("Pepito") & clave.equals("1234")) /* Para este ejercisio me tuve q fijar como se resuelve. No conocia el comando equals*/ 
            {
                System.out.println("Bienvenido Pepito!");
            }
            else if (!usuario.equals("Pepito") & clave.equals("1234"))
            {
                System.out.println("Usuario incorrecto");
            }
            else if(usuario.equals("Pepito") & !clave.equals("1234"))
            {
                System.out.println("Contraseña incorrecta");
            }    
            
     /*Ejercisio 4*/
        int m1;
        int m2;
        byte bifurcación;
        /*Abilitar el teclado*/
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Usted podra ingresar dos número y sumarlos, restarlos, multiplicarlos o dividirlos en el orden que los ingresó");
        
        System.out.println("Por favor ingrese el primer número");
        m1 = teclado.nextInt();
        
        System.out.println("Por favor ingrese el segundo número");
        m2 = teclado.nextInt();
        
        System.out.println("Por favor, ingrese el número correspondiente a la operación que desea realizar: 1-Suma, 2-Resta, 3-Multiplicación, 4-Division");
        bifurcación = teclado.nextByte(); /*Para que el usuario pueda elejir la operación*/
        
        switch (bifurcación)
        {
            case 1: 
                bifurcación = 1;
                
                System.out.println("El resultado es " + (m1 + m2)); 
                
                break;
                
            case 2:
                bifurcación = 2;
                
                System.out.println("El resultado es " + (m1 - m2));
                
                break;
                
            case 3:
                bifurcación = 3;
                
                System.out.println("El resultado es " + (m1 * m2));
                
                break;
                
            case 4:
                bifurcación = 4;
                
                System.out.println("El resultado es " + (m1 / m2));   
                
                break;
        }      
     
      
     /*Ejercisio Bonus 1*/
     System.out.println("A");
        int a1 = 20;
        int a2 = 10;
        int a3 = (a1 > a2) ? a1 : 0;
        System.out.println(a3);
     
     System.out.println("B");
        int b1 = 20;
        int b2 = 10;
        int b3 = (b1 < b2) ? b1 : 0;
        System.out.println(b3);

     System.out.println("C");
        int c1 = 20;
        int c2 = 10;
        int c3 = (c1 == c2) ? c1 : 0;
        System.out.println(c3);   
        
     System.out.println("D");
        int d1 = 20;
        int d2 = 10;
        int d3 = (d1 != d2) ? d1 : 0;
        System.out.println(d3);        
    }
}
