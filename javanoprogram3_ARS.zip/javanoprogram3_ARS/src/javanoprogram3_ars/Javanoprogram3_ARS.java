/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javanoprogram3_ars;

import java.util.Scanner;
/**
 *
 * @author EducaciónIT
 */
public class Javanoprogram3_ARS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {   
        ejercisio1();
        ejercisio2();
        ejercisio3();
        ejercisio4();
    }
    
    public static void ejercisio1 ()
    {
        byte a = 0;
        
        System.out.println("Ejercicio 1");
        
        do
        {
            System.out.println (++a);
            
        }while (a < 10);
    }

    public static void ejercisio2 ()
    {
        byte b = 10;
        
        System.out.println("Ejercicio 2");
        
        do
        {
            System.out.println(b--);
            
        }while (b > 0);
    }
    
    public static void ejercisio3 ()
    {        
        byte c = 1;
        
        System.out.println("Ejercicio 3");
        
        for (c = 1; c <= 10; ++c)
        {
            if (c != 8)
            {
                System.out.println (c);
            } 
        }
    }
    
    public static void ejercisio4 ()
    {
        byte d;
        
        System.out.println("Ejercicio 4");
        
        Scanner teclado = new Scanner (System.in);
        
        do
        {
            System.out.println ("Por favor ingresar la nota obtenida");
            d = teclado.nextByte();
        }while ((d < 0) || (d > 10));
        
        
        switch (d)
        {
            case 0 :
            case 1 :
            case 2 :
            case 3 :
                System.out.println("INSUFICIENTE");
                break;
            case 4:
                System.out.println("SUFICIENTE");
                break;
            case 5:
            case 6:
            case 7:
                System.out.println ("BIEN");
                break;
            case 8:
            case 9:
            case 10:
                System.out.println("EXCELENTE");
                break;                                          
        }
    }
}
