/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desafio2.pkg2;

import java.util.Scanner;

/**
 *
 * @author Suetta
 */
public class Desafio22 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        int maximo;
        int minimo = 0;
        
        Scanner teclado = new Scanner(System.in); 
        
        System.out.println("A continuación ingrese un númer impar: el programa dibujara una opiramide con lineas igual al número ingresado.");
        maximo = teclado.nextInt();
        
        int media = (maximo/2) + 1;
        
        /* Llamar al metodo dibujar*/
        do
        {
            String a = (minimo <= media) ? dibujar1() : "@";
                    
        }while (minimo == maximo);

    }
    
    public static String dibujar1()
    {        
        String arroba = "";

        for (int n = 1; n <= 5; n++)
        {
            arroba = arroba + "@";

            System.out.println(arroba);                

        }return arroba;
    }
    
    public static void dibujar2(int maximo)
    {  
        for (int y = (maximo/2) + 1; y <= maximo; y++)
        {
            for (int j = maximo; j > y; j--)
            {
                System.out.print("@");
            }
            System.out.println();
        }
    }
}
