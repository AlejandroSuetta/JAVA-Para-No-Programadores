/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javanoprogram_ars;

import java.util.Scanner;

/**
 *
 * @author educacionit
 */
public class Javanoprogram_ARS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        int a;
        
        System.out.println("A continuación, ingrese un número entre -10000 y 10000");
        
        Scanner teclado = new Scanner(System.in);
        a = teclado.nextInt();
        
        if (a>=0 & a<10000)
        {
            System.out.println("El número es positivo");
        }
        else if (a<0 & a>-10000)
        {       
            System.out.println("El número es negativo");
        }
        else if (a>10000 | a<-10000)
        {
            System.out.println("el número esta fuera del rango");
        }
    }
    
}
