/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desafio1;

import java.util.Scanner;

/**
 *
 * @author Suetta
 */
public class Desafio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        short a;
        short b;
        short c;
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Usted podra ingresar tres números distintos del 0 al 1000, y el programa le indicará cual número es el mayor y cuial es el menor");
        
        System.out.println("Por favor ingrese el primer número");
        a = teclado.nextShort();
        
        System.out.println("Por favor ingrese el segundo número");
        b = teclado.nextShort();
        
        System.out.println("Por favor ingrese el tercer número");
        c = teclado.nextShort();
        
        if (((a < 0) | (a > 1000)) || ((b < 0) | (b > 1000)) || ((c < 0) | (c > 1000)) || (a == b) || (a == c) || (b == c))
        {
            System.out.println("Un número ingresado esta fuera del rango especificado o esta repetido");
        }
        
        else if ((a > b) & (a > c) & (b > c))
        {
            System.out.println(a + " es el número más grande y " + c + " es el más chico");
        }
        
        else if ((a > b) & (a > c) & (c > b))
        {
            System.out.println(a + " es el número más grande y " + b + " es el más chico");
        }
        
        else if ((b > a) & (b > c) & (a > c))
        {
            System.out.println(b + " es el número más grande y " + c + " es el más chico");
        }
        
        else if ((b > a) & (b > c) & (c > a))
        {
            System.out.println(b + " es el número más grande y " + a + " es el más chico");
        }
        
        else if ((c > b) & (c > a) & (b > a))
        {
            System.out.println(c + " es el número más grande y " + a + " es el más chico");
        }
        
        else if ((c > b) & (c > a) & (a > b))
        {
            System.out.println(c + " es el número más grande y " + b + " es el más chico");
        }
    }
    
}
