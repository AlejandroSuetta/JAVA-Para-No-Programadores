/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labotarorio_clase3;

import java.util.Scanner;

/**
 *
 * @author Suetta
 */
public class Labotarorio_clase3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        /** Ejersicio 1 (while) */
        int n1 = 1;
        
        System.out.println("Ejerdicio 1 (while)");
        
        while ( n1 <= 10)
        {
            System.out.println (n1);
            
            ++n1;
        }
        
        /* Ejersicio 2 (while) */
        int n2 = 1;
        
        System.out.println("Ejersicio 2 (while)");
        
        while (n2 <= 10)
        {
           System.out.println(n2);
                   
           n2 = n2 +2;
        }
        
        /* Ejersicio 3 (while) */
        int n3 = 10;
        
        System.out.println("Ejersicio 3 (while)");      
        
        while (n3 >= 1)
        {
            System.out.println(n3);
            
            n3--;
        }
        
        /* Ejersicio 4 (while) */
        int n4 = 1;
        
        System.out.println("Ejersicio 4 (while)");
        
        while (n4 <= 10)
        {
            if ((n4 != 2) && (n4 != 5) && (n4 != 9))
            {
                System.out.println(n4);
            }
            
            ++n4;
        }
        
        /* Ejersicio 5 (while) */
        int n5 = 1;
        
        System.out.println("Ejersicio 5 (while)");
        
        while (n5 <= 30)
        {    
            if ((n5 <= 10) || (n5 >= 20))
            {
                System.out.println(n5);
            }
        
            ++n5;
        }
        
        /* Ejerscio 6 (while) */
        int n6 = 1;
        int suma = 0;
        
        System.out.println("Ejersicio 6 (while)");
        
        while (n6 <= 10)
        {
            suma = suma + n6;
            
            System.out.println(suma);
    
            ++n6;
        }
        
        /* Ejersicio 7 (while) */
        int n7 = 0;
        suma = 0;
        int resto = 0;
        
        System.out.println("Ejersicio 7 (while)");
        
        while (n7 <= 25)
        {
            resto = n7 % 2;
            
            if (resto == 0)
            {
                suma = suma + n7;
                
                System.out.println(suma);
            }
            
            ++n7;
        }
        
        /* Ejersicio 8 (while) */
        int n8 = -10;
        int multi = 1;
        resto = 0;
        
        System.out.println("Ejersicio 8 (while)");
        
        while (n8 <= 10)
        {
            resto = n8 % 2;
            
            if (resto != 0)
            {
                multi = multi * n8;
                
                System.out.println(multi);
            }
            
            ++n8;
        }
        
        /* Ejersicio 1 (for)*/
        int f1 = 1;
        
        System.out.println("Ejersicio 1 (for)");
        
        for (f1 = 1; f1 < 11; ++f1)
        {
            System.out.println(f1);
        }
        
        /* Ejersicio 2 (for) */
        int f2 = 1;
        
        System.out.println("Ejersicio 2 (for)");
        
        for (f2 = 1; f2 < 11; f2 = f2 + 2)
        {
            System.out.println(f2);
        }
        
        /* Ejersicio 3 (for) */
        int f3= 10;
        
        System.out.println("Ejersicio 3 (for)");
        
        for (f3 = 10; f3 > 0; --f3)
        {
            System.out.println(f3);
        }
        
        /*Ejersicio 4 (for) */
        int f4 = 1;
        suma = 0;
        
        System.out.println("Ejersicio 4 (for)");
        
        for (f4 = 1; f4 <11; f4 = f4 +2)
        {
            suma = suma +f4;
            
            System.out.println(suma);
        }
        
        /* Ejersicio 5 (for) */
        int f5= 1;
        suma = 0;
        multi= 1;
        int resta = 0;
        
        System.out.println("Ejersicio 5 (for)");
        
        for (f5 = 1; f5 < 6; ++f5)
        {
            suma = suma + f5;
            
            multi = multi * f5;
            
            resta = multi - suma;
            
            System.out.println(resta);            
        }
        
        /* Ejersicio 6 (for) */
        int f6 = 1;
        
        System.out.println("Ejersicio 6 (for)");
        
        for (f6 = 1; f6 < 5; ++f6)
        {
            System.out.println("@");
        }
        
        /* Ejersicio 7 (for) */
        int f7 = 1;
        resto = 0;
        
        System.out.println("Ejersicio 7 (for)");
        
        for (f7 = 1; f7 < 6; ++f7)
        {
            resto = f7 % 2;
            
            if (resto != 0)
            {
                System.out.println("@");
            }
            
            else
            {
                System.out.println("@@");
            }
        }
        
        /* Ejersicio 8 (for) */
        int f8 = 1;
        String x = "";
        
        System.out.println("Ejersicio 8 (for)");
        
        for (f8 = 1; f8 < 6; ++f8)
        {
            x = x + "@";
            
            System.out.println(x);
        }
        
        /* Ejersicio 9 (for) */
        int f9 = 1;
        
        System.out.println("Ejersicio 9 (for)");
        
        for (f9 = 1; f9 < 6; ++f9)
        {
            for(int j = 6; j > f9 ; --j )
            {
                System.out.print("@");
            }
            
            System.out.println();
        }
        
        /* Ejersicio 10 (for) */
        int f10 = 1;
        x = "";
        
        System.out.println("Ejersicio 10 (for)");
        
        for (f10 = 1; f10 <= 4; ++f10)
        {
            x = x + "@";
            
            System.out.println(x);
        }
        
        for (int i = 1; i < 4; ++i)
        {
            for (int h = 4; h > i; --h )
            {
                System.out.print("@");
            }
            
            System.out.println();
        }
        
        /*Ejersicio 11 (for) */
        int cantInicial=5;
        int cantMedia=1;
        int incremento=-2;
        int cantFinal=cantInicial-incremento;
        int cantArrobas=0;
        int cantArrobasLinea=cantInicial;
        int contadorLineas=0;
        
        System.out.println("Ejersicio 11 (for)");

        while(cantArrobasLinea!=cantFinal || contadorLineas==0)
        {
            for(cantArrobas=1;cantArrobas<=cantArrobasLinea;cantArrobas++)
            {
                System.out.print("@");
            }

            System.out.println();

            cantArrobasLinea+=incremento;

            if(cantArrobasLinea==cantMedia)
            {
                incremento=-incremento;
            }

            contadorLineas++;
        }
        
        /* Ejersicio 1 (while) */
        int w1 =1;
        suma = 0;
        
        System.out.println("Ejersicio 1 (while)");
        
        while (w1 <= 30)
        {
            resto = w1 % 2;
            
            if ((resto == 0) & (w1 > 9) & (w1 < 20))
            {
                suma = suma + w1;
                
                System.out.println(suma);
            }
                      
            ++w1;
        }
        
        /* Ejersicio 2 (while) */
        int w2 = 1;
        int mayor = 0;
        int menor = 0;
        int numero = 0;
        
        Scanner teclado = new Scanner (System.in);
        
        System.out.println("Ejersicio 2 (while)");
        
        while (w2 <= 5)
        {
            System.out.println("Ingrese un número");
            
            numero = teclado.nextInt();
            
            if (numero > mayor)
            {
                mayor = numero;
            }
            
            if (numero < menor)
            {
                menor = numero;
            }
            
            else
            {
                menor = mayor;
            }
            
            ++w2;
        }
        
        System.out.println("El mayor es " + mayor);
        
        System.out.println("El menor es " + menor);
        
        /* Ejersicio 3 (while)*/
        int euro = 1;
        
        while (euro <= 10)
        {
            double pesos = euro * 5.8;
            
            System.out.println(pesos);
            
            ++euro;
        }
        
        /* Ejersicio 4 (while)*/
         int mes = 1;
         double interes = 1000;
         
         System.out.println ("Ejersiscio 4 (while)");
         
         while (mes <= 12)
         {
             interes = interes + (interes * 0.02);
             
             System.out.println(interes);
             
             ++mes;
         }
         
         /* Ejersicio 5 (while)*/
         mes = 1;
         double dinero = 1000;
         
         System.out.println("Ejersicio 5 (while)");
         
         while (dinero <= 1200)
         {
             dinero = dinero + (dinero * 0.03);
             
             System.out.println(mes);
             
             ++mes;
         }
         
         /* Ejersicio 6 (do/while)*/
         int w6 = 3; 
         
         do
         {
             System.out.println("Por favor, ingrese su contraseña. Tiene " + w6 + " intentos");
             String contraseña = teclado.next();
             
             if (contraseña.equals("celular"))
             {
                 System.out.println("Bienvenido!");
                 
                 break;
             }
             
             --w6;
             
         }while (w6 > 0); 
         
         if (w6 == 0)
         {    
             System.out.println("Tres veces falladas");
         }
    }
}