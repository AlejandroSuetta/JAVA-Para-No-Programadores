/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase;

/**
 *
 * @author EducaciónIT
 */
public class Clase {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        int[] a = new int[4]; /*Definir un arreglo*/
            a[0] = 111;
            a[1] = 222;
            a[2] = 333;
            a[3] = 444;
        
        int[] b = new int[5];
            
        for (int elem = 0; elem < a.length; elem++)
        {
            System.out.println("Arreglo a : elemento " + (elem + 1) + " = " + a[elem]);
        }
        
        System.arraycopy(a, 0, b, 2, 2);
                
        for (int elem = 0; elem < b.length; elem++)
        {
            System.out.println("Arreglo b : elemento " + (elem + 1) + " = " + b[elem]);
        }
        
        int[] b = {1,2,3,4}; /*Definir un arreglo*/
        
        String[] meses = {"Enero","Febrero","Marzo"}; /*Tambiém es un arreglo*/
        
        int[] c = new int[5]; /*Definir un arreglo*/
        c = new int[7]; /*Redefinir un arreglo, pero se borra el valor anterior*/
        
        System.arraycopy();        
    }
    
}
