/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication6;

import java.util.Scanner;

/**
 *
 * @author Suetta
 */
public class JavaApplication6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        int x;
        int y = 1;
        String z = "";          
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Por favor ingres un número impar positivo");
        x = teclado.nextByte();

        do
        {        
            for (y = 1; y <= ((x/2) + 1) ; y++)
            {
                z = z + "@";
            
                System.out.println (z);            
            }
     
            for (y = ((x/2) + 1); y <= x; y++)
            {
                for (int j = x; j > y; j--)
                {
                    System.out.print("@");
                }
                System.out.println();
            }
        }while (y <= x);
    }   
}