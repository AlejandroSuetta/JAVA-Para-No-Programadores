/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase4;

import java.util.Scanner;

/**
 *
 * @author EducaciónIT
 */
public class clase4 {
    
    // Constante para corte del programa
    final static byte SALIR = -1;
        
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        byte nota;
        
        do
        {
            System.out.println( "A continuación, ingrese una nota (de 0 a 10). '-1' para salir.");
            
            // Ingreso la nota por teclado. '-1' para salir
            nota = leer_nota();
            
            // valido
            if( validar_nota(nota) )
            {
                if( nota != SALIR )
                    mostrar_calificacion(nota); // muestro la calificación
            }
            else
                System.out.println("El valor ingresado es inválido");            
        } while( nota != -1);
    }
    
    public static byte leer_nota()
    {
        Scanner teclado = new Scanner(System.in);

        return teclado.nextByte();
    }
    
    public static boolean validar_nota(byte nota)
    {
        return ( (nota >= 0 && nota <= 10) || nota == SALIR );
    }
    
    public static void mostrar_calificacion(byte nota)
    {
        switch( nota )
        {
            case 0: case 1: case 2: case 3:
                System.out.println("INSUFICIENTE");
                break;
            case 4:
                System.out.println("SUFICIENTE");
                break;
            case 5: case 6: case 7:
                System.out.println("BIEN");
                break;
            default:
                System.out.println("EXCELENTE");
        }
    }
}